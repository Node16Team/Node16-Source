<?php
$servername = "localhost";
$username = "nodexyz_dbadmin";
$password = "phpadmin123lulz";
$dbname = "nodexyz_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

if (isset($_GET['id'])) {
    $Id = $_GET['id'];
   
    $sql = "SELECT ownedBy, name, publishDate, updatedDate, description, likes, dislikes, visited, online, genre, gearsAllowed, maxPlayers, favourites FROM games WHERE id = '$Id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $ownedBy = $row['ownedBy'];
        $name = htmlspecialchars($row['name'], ENT_COMPAT,'ISO-8859-1', true);
        $description = htmlspecialchars($row['description'], ENT_COMPAT,'ISO-8859-1', true);
        $publishDate = $row['publishDate'];
        $updatedDate = $row['updatedDate'];
        $likes = $row['likes'];
        $dislikes = $row['dislikes'];
        $genre = $row['genre'];
        $maxPlayers = $row['maxPlayers'];
        $visited = $row['visited'];
        $favourites = $row['favourites'];
    } else {
        header("Location: /404.php");
        exit();
    }
} else {
    header("Location: /404.php");
    exit();
}


$conn->close();
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" xmlns:fb="http://www.facebook.com/2008/fbml"><head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,requiresActiveX=true">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Language" content="en-us">
    <meta name="author" content="NODE16 Fandom">
    <meta name="description" content="User-generated MMO gaming site for kids, teens, and adults. Players architect their own worlds. Builders create free online games that simulate the real world. Create and play amazing 3D games. An online gaming cloud and distributed physics engine.">
    <meta name="keywords" content="free games, online games, building games, virtual worlds, free mmo, gaming cloud, physics engine">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0">


    <title>NODE16 Games - Browse our selection of free online games</title>
    <link rel="icon" type="image/vnd.microsoft.icon" href="/favicon.ico">
    
    

<!--these links are STILL active, roblox is just lazy ngl-->
<link rel="stylesheet" href="/static/css/Roblox.css">
<link rel="stylesheet" href="/static/css/common.css">
<style>
/* replaces Ads.css */
    /*
    This file is for rules to style ad slots run on the website, NOT for styling content related to creating or managing user ads
*/
body.banner
{
    background-color: transparent;
}
.ad-annotations
{
    width: 100%;
    height: 11px;
    position: relative;
    margin: 0 auto;
    font-size: 11px;
    z-index: 100;       /* fix so it's on top of the banner below it */
}
.ad-annotations.left-gutter-ad {
    width: auto;
}
.ad-annotations.left-gutter-ad .ad-identification {
    left: auto;
    right: 0;
}
.ad-identification
{
    position: absolute;
    left: 0;
}
.dark-theme-ad-annotation, .dark-theme-ad-annotation .BadAdButton:link
{
    color: #fff;
}
.BadAdButton
{
    position: absolute;
    right: 0;
}
.BadAdButton:link
{
    color:#80ace6;
}
.Ads_WideSkyscraper
{
	float: right;
	text-align: right;
	width: 160px;
	height: 611px;
}
#AdvertisingLeaderboard
{
    margin: 0 auto;
    text-align: center;
    padding-top: 5px;
    margin-bottom:10px;    
    width: 728px; /* smaller to account for the left positioning of the ad */
}

.GPTAd.banner {
    width: 745px;
    height: 90px;
}
.GPTAd.skyscraper {
    width: 160px;
    height: 600px;
}
.GPTAd.rectangle {
    width: 300px;
    height: 250px;
}
.GPTAd.narrowskyscraper {
    width: 120px;
    width: 600px;
}
.GPTAd.gutter {
    width: 400px;
    height: 1180px;
}
.GPTAd.opapushdown {
    width: 970px;
    height: 96px;
}
.GPTAd {
    overflow: hidden;
    margin: 0 auto;
}

#FloorAd {
    height: 1px;
}

</style>
<link rel="stylesheet" href="/static/css/flyouts.css">
<link rel="stylesheet" href="/static/css/footer.css">
<style>
    /* replaces Header.css */
    div#testingSitePanelWrapper, #BodyWrapper {
        margin:0 auto;
        width:970px;
        background:white;
    }
</style>
<link rel="stylesheet" href="/static/css/loginiframe.css">
<link rel="stylesheet" href="/static/css/item.css">
<link rel="stylesheet" href="/static/css/jqcs.css">
<link rel="stylesheet" href="/static/css/spinner.css">
<style>
    /* replaces MediaThumb.css */
    div.MediaPlayerControls
{
    position: relative;
    margin: 0;
    padding: 0;
    width: 0;
    height: 0;
    border: 0;
}
div.MediaPlayerIcon 
{
    background-image:url(https://www.roblox.com/images/AssetIcons/MediaPlayerIcons.png);
    background-repeat:no-repeat;
    width: 25px;
    height: 25px;
    border: 0;
}
.MediaPlayerIcon.Play
{
    background-position: left top;
    cursor: pointer;
}
.MediaPlayerIcon.Play:hover
{
    background-position: right top;
}
.MediaPlayerIcon.Pause
{
    background-position: left center;
    cursor: pointer;
}
.MediaPlayerIcon.Pause:hover
{
    background-position: right center;
}
.MediaPlayerIcon.Error
{
    background-position: left bottom;
}
</style>
<link rel="stylesheet" href="/static/css/modals.css">
<link rel="stylesheet" href="/static/css/nav.css">
<link rel="stylesheet" href="http://www.roblox.com/CSS/Base/CSS/Party.css">
<link rel="stylesheet" href="/static/css/place.css">
<link rel="stylesheet" href="/static/css/pl.css">
<link rel="stylesheet" href="/static/css/guestchar.css">
<link rel="stylesheet" href="/static/css/thumb.css">
<link rel="stylesheet" href="/static/css/gamepage.css">
<link rel="stylesheet" href="/static/css/tipsy.css">
<link rel="stylesheet" href="http://www.roblox.com/CSS/Base/CSS/Trade.css">
<link rel="stylesheet" href="http://www.roblox.com/CSS/Base/CSS/Upgrades.css">
<link rel="stylesheet" href="http://www.roblox.com/CSS/Base/CSS/User.css">
<link rel="stylesheet" href="/static/css/utility.css">
<link rel="stylesheet" href="/static/css/vidpreroll.css">
<link rel="stylesheet" href="/static/css/styleguide.css">

    
<link rel="stylesheet" href="/static/css/styleguide.css">
<link rel="stylesheet" href="/static/css/votingpanel.css">
</head>
<body class="">
    


<div id="fb-root"></div>

<div class="nav-container no-gutter-ads nav-open">


<div class="nav-icon" onselectstart="return false;" style="display: none;">
</div>

<!-- MENU -->
<div class="header-2014 clearfix">
    <div class="header-container">
        <a href="/"><span class="logo" style="margin: 3px 0px 0px 45px;"></span></a>
            <div id="header-login-container" class="right">
                <div id="header-login-wrapper" class="iframe-login-signup" data-display-opened="False">
                    <a id="header-signup" href="/Login/NewAge.aspx">Sign Up</a>
                    <span id="header-or">or</span>
                    <span id="login-span">
                        <a id="header-login" class="btn-control btn-control-large">Login <span class="grey-arrow">▼</span></a>
                    </span>
                    <div id="iFrameLogin" style="display: none; height: 128px;">
                        <iframe class="login-frame" src="/Login/iFrameLogin.aspx?loginRedirect=True&amp;parentUrl=http%3a%2f%2fwww.roblox.com%2fGames" scrolling="no" frameborder="0" data-ruffle-polyfilled=""></iframe>
                    </div>
                </div>
            </div>
        <div class="header-links">
            <a href="/games">
                <div class="games">
                    Games
                </div>
            </a>
            <a href="/catalog">
                <div class="catalog">
                    Catalog
                </div>
            </a>
            <a href="/develop">
                <div class="develop">
                    Develop
                </div>
            </a>
            <a class="buy-robux" href="/upgrades/robux">
                <div class="buy-robux">
                    ROBUX
                </div>
            </a>
        </div>
        <div class="search">
            <div class="search-input-container">

                <input type="text" placeholder="Search">
            </div>
            <div class="search-icon"></div>
            <div class="universal-search-dropdown">
                <div class="universal-search-option selected" data-searchurl="/catalog/lists.aspx?q=">
                    <div class="universal-search-text">Search <span class="universal-search-string"></span> in Games</div>
                </div>
                        <div class="universal-search-option" data-searchurl="/Browse.aspx?name=">
                            <div class="universal-search-text">Search <span class="universal-search-string"></span> in People</div>
                        </div>
                        <div class="universal-search-option" data-searchurl="/catalog/browse.aspx?CatalogContext=1&amp;Keyword=">
                            <div class="universal-search-text">Search <span class="universal-search-string"></span> in Catalog</div>
                        </div>
                        <div class="universal-search-option" data-searchurl="/groups/search.aspx?val=">
                            <div class="universal-search-text">Search <span class="universal-search-string"></span> in Groups</div>
                        </div>
                        <div class="universal-search-option" data-searchurl="/develop/library?CatalogContext=2&amp;Category=6&amp;Keyword=">
                            <div class="universal-search-text">Search <span class="universal-search-string"></span> in Library</div>
                        </div>
            </div>
        </div>
    </div>
</div>
<div id="navContent" class="nav-content" style="margin-left: 0px; width: 100%;">
<div class="nav-content-inner">
<div id="MasterContainer">
        <script type="text/javascript">
            if (top.location != self.location) {
                top.location = self.location.href;
            }
        </script>
    

    <div>
                        <noscript><div class="SystemAlert"><div class="SystemAlertText">Please enable Javascript to use all the features on this site.</div></div></noscript> <div class="SystemAlert"><div class="SystemAlertText" style="color: black;">simple is working on this, no touch</div></div>
        <div id="BodyWrapper">
            <div id="RepositionBody">
                <div id="Body" style="width:970px;">
                    
    

    <div id="ItemContainer" class="PlaceItemContainer new-game-page">
        
        <div class="Ads_WideSkyscraper" style="float:right">
<div style="width: 160px">
    <span id="3131383435353033" class="GPTAd skyscraper" data-js-adtype="gptAd"></span>
    </span>
    <div class="ad-annotations " style="width: 160px">
        <span class="ad-identification">Advertisement
        </span>
            <a class="BadAdButton" href="/web/20141016195552/http://www.roblox.com/Ads/ReportAd.aspx" title="click to report an offensive ad">Report</a>
    </div>
</div></div>

        
        

<div id="Item" class="place-item redesign body">
    <div class="item-header">
        <h1 class="notranslate"><?php echo $name; ?></h1>
        
        
    </div>
    <div class="left-column">
        <div class="item-media">
            
<script type="text/javascript">
    if (typeof Roblox === "undefined") {
        Roblox = {};
    }
    if (typeof Roblox.FileUploadUnsupported === "undefined") {
        Roblox.FileUploadUnsupported = {};
    }
    Roblox.FileUploadUnsupported.Resources = {
        //<sl:translate>
        notSupported: " This device does not support file upload."
        //</sl:translate>
    };
    if (typeof Roblox.CreateSetPanel === "undefined") {
        Roblox.CreateSetPanel = {};
    }
    Roblox.CreateSetPanel.Resources = {
        //<sl:translate>
        youMaySelect: "You may select a maximum of ",
        elementsInList: " elements from this list!"
        //</sl:translate>
    };
</script>
        <style type="text/css">
        .youTubeVideoOverlay 
        {
            position:absolute;
            top:0px;
            left:0px;
            width: 120px;
            height: 70px;
            z-index:5;
            cursor: pointer;
            background: white;
            opacity: 0.0;
            filter: alpha(opacity=0.0);
        }
        .SelectedYouTubeGalleryIcon
        {
            top: -3px; 
            margin: 2px !important;  /** !important makes sure we override the margin in divSmallGalleryItem **/ 
            border: 3px solid black; /** If you change this border size, you need to change the margin, as well as the top value **/
        }
        .RemoveYouTubeGalleryImage
        {
            cursor: pointer; 
            position: absolute; 
            top: -10px; 
            right: -10px; 
            z-index: 6; /** Make sure this is higher than z-index of youTubeVideoOverlay **/
        }
        .divSmallGalleryItem
        {
            height: 70px; 
            width: 120px; 
            float: left;
            position:relative;
            margin: 5px;
        }
        #divSmallGalleryItemBox
        {
            width: 500px; 
            height:100px;
            position:relative;
            overflow-x: auto; 
            overflow-y: hidden;
        }
        #divSmallGalleryScrollContainer
        {
            margin: 0px auto; 
            margin-top: 5px; 
            margin-bottom: 5px; /** Allows for scroll bar **/
            display: inline-block; 
            width: 0px;
            *display:inline;
            *zoom:1;
        }
        .smallGalleryThumbItem
        {
            float: left; 
        }
        </style>

        <div style="margin: 0px auto; width: 500px">
        <div id="ItemThumbnail" style="height:280px; width: 500px">
        <div id="bigGalleryThumbItem" style="position: absolute;">
            <a id="ctl00_cphRoblox_NewGamePageControl_RichMediaThumbDisplay_rbxGalleryAssetThumbnail_rbxAssetImage" class=" notranslate" title="Roblox Town: News Team (working microphone!)" onclick="__doPostBack('ctl00$cphRoblox$NewGamePageControl$RichMediaThumbDisplay$rbxGalleryAssetThumbnail$rbxAssetImage','')" style="display:inline-block;height:280px;width:500px;cursor:pointer;"><img src="https://web.archive.org/web/20141016195552im_/http://t7.rbxcdn.com/69d4c44d0e59c28e989d6ba724806da6" height="280" width="500" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="simples fandom" class=" notranslate"></a>




            </div>
            </div>
                

    

    

</div>



            
            
        </div>
        <div class="actions logged-out">
            
            <div class="voting"><div class="voting-panel body" data-asset-id="167336954" data-total-up-votes="1892" data-total-down-votes="795" data-vote-modal="">
    <div class="loading"></div>
        <div class="vote-summary">
            <div class="voting-details">
                <div class="total-upvotes divider-right">
                    <div class="tiny-thumbs-up"></div>
                    <span>
                        Thumbs up:
                        <span class="total-upvotes-text"><?php echo $likes; ?></span>
                    </span>
                </div>
                <div class="total-downvotes">
                    <span>
                        Thumbs down:
                        <span class="total-downvotes-text"><?php echo $dislikes; ?></span>
                    </span>
                    <span class="tiny-thumbs-down"></span>
                </div>
                <div class="clear"></div>
            </div>
            <div class="visual-container">
                <div class="background votes"></div>
                <div class="percent" style="width: 100%;"></div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="clear"></div>
</div>
</div>
            <div class="clear"></div>
            <span class="ReportAbuse">
                <div id="ctl00_cphRoblox_NewGamePageControl_AbuseReportButton_AbuseReportPanel" class="ReportAbuse">
	
    <span class="AbuseIcon"><a id="ctl00_cphRoblox_NewGamePageControl_AbuseReportButton_ReportAbuseIconHyperLink" href="abusereport/asset?id=167336954&amp;RedirectUrl=http%3a%2f%2fwww.roblox.com%2fPlaceItem.aspx%3fseoname%3dRoblox-Town-News-Team-working-microphone%26id%3d167336954"><img src="/web/20141016195552im_/http://www.roblox.com/images/abuse.PNG?v=2" alt="Report Abuse" style="border-width:0px;"></a></span>
    <span class="AbuseButton"><a id="ctl00_cphRoblox_NewGamePageControl_AbuseReportButton_ReportAbuseTextHyperLink" href="abusereport/asset?id=167336954&amp;RedirectUrl=http%3a%2f%2fwww.roblox.com%2fPlaceItem.aspx%3fseoname%3dRoblox-Town-News-Team-working-microphone%26id%3d167336954">Report Abuse</a></span>

</div>
            </span>
        </div>
        <div class="description notranslate">
            <div id="DescriptionText" class="invisible"><?php echo $description; ?></div>
            <pre id="PlaceDescription" class="body"><?php echo $description; ?></pre>
        </div>
        <div class="facebook-like">
                
        </div>
    </div>
    <div class="right-column">
        <div class="builder divider-bottom">
            <div class="builder-image">
            
                <div class="roblox-avatar-image" data-user-id="1696905" data-image-size="tiny"></div>
            
            </div>
            <div class="builder-name"><span>Builder: </span><span class="notranslate"><a href="/User.aspx?ID=1" class="tooltip" original-title="Janlari"><?php echo $ownedBy; ?></a></span></div>
            <div class="builder-joined"><span class="stat-label">Joined: </span><span class="stat">12/9/2008</span></div>
            <div class="clear"></div>
        </div>
        <div class="buttons">
            
            <div id="VisitButtonContainer">
                
        <div class="VisitButtonsLeft Centered">
            
            <div id="ctl00_cphRoblox_NewGamePageControl_VisitButtons_MultiplayerVisitButton" class="VisitButton VisitButtonPlay" placeid="167336954">
                <a class="btn-medium btn-primary">Play</a>
            </div>  
            
            
        </div>
    

    <script type="text/javascript">
        var play_placeId = 167336954;
        function redirectPlaceLauncherToLogin() {
            location.href = "/login/default.aspx?ReturnUrl=" + encodeURIComponent("/PlaceItem.aspx?seoname=Roblox-Town-News-Team-working-microphone&id=167336954");
        }
        function redirectPlaceLauncherToRegister() {
            location.href = "/login/NewAge.aspx?ReturnUrl=" + encodeURIComponent("/PlaceItem.aspx?seoname=Roblox-Town-News-Team-working-microphone&id=167336954");
        }
        function fireEventAction(action) {
            RobloxEventManager.triggerEvent('rbx_evt_popup_action', { action: action });
        }
    </script>
    

<div class="GenericModal modalPopup unifiedModal smallModal" style="display:none;">
    <div class="Title"></div>
    <div class="GenericModalBody">
        <div>
            <div class="ImageContainer roblox-item-image" data-image-size="small" data-no-overlays="" data-no-click="">
                <img class="GenericModalImage" alt="generic image">
            </div>
            <div class="Message"></div>  
            <div style="clear:both"></div>
        </div>
        <div class="GenericModalButtonContainer">
            <a class="ImageButton btn-neutral btn-large roblox-ok">OK<span class="btn-text">OK</span></a> 
        </div>  
    </div>
</div>


    
                
                    
                
            </div>
			
        </div>
        <div class="details ">
            <div class="statistics">
                <div><span class="stat-label">Created:</span><span class="stat"><?php echo $publishDate; ?></span></div>
                <div><span class="stat-label">Updated:</span><span class="stat"><?php echo $updatedDate; ?></span></div>
                <div><span class="stat-label">Favorited:</span><span class="stat"><?php echo $favourites; ?></span></div>
                <div><span class="stat-label">Visited:</span><span class="stat"><?php echo $visited; ?></span></div>
                <div><span class="stat-label">Max Players:</span><span class="stat"><?php echo $maxPlayers ?></span></div>
                <div>
                </div>
                
            </div>
            
            <span class="stat-label">Genres:</span><span class="stat"><a href="#"><?php echo $genre ?></a></span>
            
            <div id="ctl00_cphRoblox_NewGamePageControl_Div1" class="allowed-gear">
                <div class="stat-label">Allowed Gear Types:</div><div>        <div class="category-icon all tooltip" original-title="All Gear Allowed"></div>

<div class="clear"></div></div>
            </div>
            <div class="configure divider-top invisible">
                <div class="form-label">Options</div>
                <div><a href="/My/Item.aspx?id=167336954">Configure this Place</a></div>
                <div><a href="/My/NewUserAd.aspx?targetID=167336954">Advertise this Place</a></div>
                <div><a href="/My/NewBadge.aspx?targetID=167336954">Create a Badge for this Place</a></div>
                <div><a href="/My/ContentBuilder.aspx?ContentType=34&amp;PlaceID=167336954">Create a Game Pass</a></div>
                <div>
                    <a href="/universes/configure?id=79890834">Configure this Game</a> 
                </div>
                <div><a href="/places/167336954/stats">Developer Stats</a></div>          
            </div>
            <div class="clear"></div>
        </div>
    </div>
</div>

    
        
        <div class="clear"></div>
        <div>
            <div>
                
                
                <div class="ItemPurchaseAjaxContainer">
                    

<div id="ItemPurchaseAjaxData" data-authenticateduser-isnull="True" data-user-balance-robux="0" data-user-balance-tickets="0" data-user-bc="0" data-continueshopping-url="" data-imageurl="" data-alerturl="http://images.rbxcdn.com/cbb24e0c0f1fb97381a065bd1e056fcb.png" data-builderscluburl="http://images.rbxcdn.com/ae345c0d59b00329758518edc104d573.png"></div>

    <div id="ProcessingView" style="display:none">
        <div class="ProcessingModalBody">
            <p style="margin:0px"><img src="https://images.rbxcdn.com/ec4e85b0c4396cf753a06fade0a8d8af.gif" alt="Processing..."></p>
            <p style="margin:7px 0px">Processing Transaction</p>
        </div>
    </div>

                </div>
                 
                <div class="redesign">
                    <a name="tabRegion">&nbsp;</a>
                    <div id="ctl00_cphRoblox_TabbedInfo" class="tab_white_31h_container ajax__tab_container ajax__tab_default" style="visibility: visible;">
	<div id="ctl00_cphRoblox_TabbedInfo_header" class="ajax__tab_header">
		<span id="ctl00_cphRoblox_TabbedInfo_RecommendationsTabPageRedesign_tab" class="ajax__tab_active"><span class="ajax__tab_outer"><span class="ajax__tab_inner"><span id="__tab_ctl00_cphRoblox_TabbedInfo_RecommendationsTabPageRedesign" class="ajax__tab_tab">
                                <h3>Recommendations</h3>
                            </span></span></span></span><span id="ctl00_cphRoblox_TabbedInfo_GamesTab_tab"><span class="ajax__tab_outer"><span class="ajax__tab_inner"><span id="__tab_ctl00_cphRoblox_TabbedInfo_GamesTab" class="ajax__tab_tab">
                                <h3 class="roblox-games-tab">Games</h3>
                            </span></span></span></span><span id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_tab"><span class="ajax__tab_outer"><span class="ajax__tab_inner"><span id="__tab_ctl00_cphRoblox_TabbedInfo_CommentaryTab" class="ajax__tab_tab">
                                <h3 class="roblox-comments-tab">Commentary</h3>
                            </span></span></span></span>
	</div><div id="ctl00_cphRoblox_TabbedInfo_body" class="ajax__tab_body">
		<div id="ctl00_cphRoblox_TabbedInfo_RecommendationsTabPageRedesign" style="visibility: visible;" class="ajax__tab_panel">
			
                                

    <div class="AssetRecommenderContainer">
    <table id="ctl00_cphRoblox_TabbedInfo_RecommendationsTabPageRedesign_AssetRecommenderRedesign_dlAssets" cellspacing="0" align="Center" border="0" style="height:175px;width:890px;border-collapse:collapse;">
				<tbody><tr>
					<td>
            <div class="WideAspectRatio" style="width: 140px;overflow: hidden;margin:auto;" visible="False" data-se="recommended-items-0">
                <div class="AssetThumbnail">
                    <a id="ctl00_cphRoblox_TabbedInfo_RecommendationsTabPageRedesign_AssetRecommenderRedesign_dlAssets_ctl00_AssetThumbnailHyperLink" class=" notranslate" title="simples fandom" href="/games/view/?id=1" style="display:inline-block;height:100px;width:160px;cursor:pointer;"><img src="/static/img/gametemp.png" height="100" width="160" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="simples fandom" class=" notranslate"></a>
                </div>
                <div class="AssetDetails">
                    <div class="AssetName noTranslate">
                        <a id="ctl00_cphRoblox_TabbedInfo_RecommendationsTabPageRedesign_AssetRecommenderRedesign_dlAssets_ctl00_AssetNameHyperLinkPortrait" href="/games/view/?id=1">simples fandom</a>
                    </div>
                    <div class="AssetCreator">
                        <span class="stat-label">Creator:</span> <span class="Detail stat"><a id="ctl00_cphRoblox_TabbedInfo_RecommendationsTabPageRedesign_AssetRecommenderRedesign_dlAssets_ctl00_CreatorHyperLinkPortrait" class="notranslate" href="/User.aspx?ID=1337010">ROBLOX</a></span>
                    </div>
                </div>
            </div>
        </td><td>
        </td><td>
        </td><td>
        </td><td></td>
				</tr>
			</tbody></table>
    
</div>


                            
		</div><div id="ctl00_cphRoblox_TabbedInfo_GamesTab" style="display:none;visibility:hidden;" class="ajax__tab_panel">
			
                                <div id="ctl00_cphRoblox_TabbedInfo_GamesTab_RunningGamesList_RunningGamesUpdatePanel">
				
        <div id="ctl00_cphRoblox_TabbedInfo_GamesTab_RunningGamesList_LoadGamesButtonDiv" style="padding:5px; text-align:center;"><a id="ctl00_cphRoblox_TabbedInfo_GamesTab_RunningGamesList_LoadGamesButton" class="btn-primary btn-medium roblox-running-games-btn" href="javascript:__doPostBack('ctl00$cphRoblox$TabbedInfo$GamesTab$RunningGamesList$LoadGamesButton','')"><span>Load Games</span></a></div>

        
    
			</div>

                                
		</div><div id="ctl00_cphRoblox_TabbedInfo_CommentaryTab" style="display:none;visibility:hidden;" class="ajax__tab_panel">
			
                               <div id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsUpdatePanel">
				
        <div id="AjaxCommentsPaneData"></div>

        <div class="AjaxCommentsContainer">
            
            <div class="Comments" data-asset-id="167336954"></div>
            
            <div class="CommentsItemTemplate">
                    <div class="Comment text">
                        <div class="Commenter">
                            <div class="Avatar" data-user-id="%CommentAuthorID" data-image-size="small">
                            </div>
                        </div>
                        <div class="PostContainer">
                            <div class="Post">
                                <div class="Audit">
                                    <span class="ByLine footnote"><div class="UserOwnsAsset" title="User has this item" alt="User has this item" style="display:none;"></div>Posted %CommentCreated ago by <a href="/web/20141016195552/http://www.roblox.com/user.aspx?id=%CommentAuthorID">%CommentAuthor</a></span>
                                    <div class="ReportAbuse">
                                        <span class="AbuseButton">
                                            <a href="/web/20141016195552/http://www.roblox.com/abusereport/comment?id=%CommentID&amp;redirectUrl=%PageURL">Report Abuse</a>
                                        </span>
                                    </div>
                                    <div style="clear:both;"></div>
                                </div>
                                <div class="Content">
                                    %CommentContent
                                </div>
                                <div id="Actions" class="Actions">
                                    <a data-comment-id="%CommentID" class="DeleteCommentButton">Delete Comment</a>
                                </div>
                            </div>
                            <div class="PostBottom"></div>
                        </div>
                        <div style="clear:both;"></div>
                    </div>
                </div>
        </div>

			</div>

<script type="text/javascript">
    Roblox.CommentsPane.Resources = {
        //<sl:translate>
        defaultMessage:         'Write a comment!',
        noCommentsFound:		'No comments found.',
        moreComments:			'More comments',
        sorrySomethingWentWrong:'Sorry, something went wrong.',
        charactersRemaining:	' characters remaining',
        emailVerifiedABTitle:	'Verify Your Email',
        emailVerifiedABMessage: "You must verify your email before you can comment. You can verify your email on the <a href='/my/account?confirmemail=1'>Account</a> page.",
        linksNotAllowedTitle:   'Links Not Allowed',
        linksNotAllowedMessage: 'Comments should be about the item or place on which you are commenting. Links are not permitted.',
        accept:					'Verify',
        decline:				'Cancel',
        tooManyCharacters:		'Too many characters!',
        tooManyNewlines:		'Too many newlines!'
        //</sl:translate>
       };

       Roblox.CommentsPane.Limits =
       [	{ limit: '10'
            , character: "\n"
            , message: Roblox.CommentsPane.Resources.tooManyNewlines
            }
       ,	{ limit: '200'
            , character: undefined
            , message: Roblox.CommentsPane.Resources.tooManyCharacters
            }
       ];

       Roblox.CommentsPane.FilterIsEnabled = true;
       Roblox.CommentsPane.FilterRegex = "(([a-zA-Z0-9-]+\\.[a-zA-Z]{2,4}[:\\#/\?]+)|([a-zA-Z0-9]\\.[a-zA-Z0-9-]+\\.[a-zA-Z]{2,4}))";
       Roblox.CommentsPane.FilterCleanExistingComments = false;

    Roblox.CommentsPane.initialize();
</script>

                               
                            
		</div>
	</div>
</div>
                    <script type="text/javascript">
                        var commentsLoaded = false;
                        var gamesLoaded = false;
                        var tabNames = {
                            "Commentary": "roblox-comments-tab",
                            "Games": "roblox-games-tab"
                        };
                        function isActivatingTab(sender, tabName) {
                            var tabHeader = $(sender._tabs[sender._activeTabIndex]._header).find("h3");
                            return tabHeader.hasClass(tabNames[tabName]);
                        }
                        function LoadComments(sender, eventargs) {
                            if (isActivatingTab(sender, "Commentary") && !commentsLoaded) {
                                Roblox.CommentsPane.getComments(0);
                                if (Roblox.SuperSafePrivacyMode != undefined) {
                                    Roblox.SuperSafePrivacyMode.initModals();
                                }
                                commentsLoaded = true;
                            }
                            if (isActivatingTab(sender, "Games") && !gamesLoaded) {
                                Roblox.RunningGamesList.Load();
                                gamesLoaded = true;
                            }
                        }
                    </script>
                    
                    
            </div>
            <div class="clear"></div>
        </div>
    
    </div>

                    <div style="clear:both"></div>
                </div>
            </div>
        </div>

<script type="text/javascript">
    Roblox.SearchBox = {};
    Roblox.SearchBox.Resources = {
        //<sl:translate>
        search: "Search",
        zeroResults: "No Search Results Found"
        //</sl:translate>
    };
    Roblox.GamesPageContainerBehavior.Resources = {
        //<sl:translate>
        pageTitle: "ROBLOX Games - Browse our selection of free online games"
        //</sl:translate>
    };
    
    var defaultGamesLists = "0,8,9,11,14";
    Roblox.GamesPageContainerBehavior.FilterValueToGamesListsIdSuffixMapping = {"default": defaultGamesLists.split(',')};
    
    Roblox.GamesPageContainerBehavior.IsUserLoggedIn = false;
    Roblox.GamesPageContainerBehavior.adRefreshRateMilliSeconds = 3000;

    Roblox.GamesPageContainerBehavior.PromptForEmailAddress = false;
    Roblox.GamesPageContainerBehavior.PromptForEmailAddressDelayInMs = 0;
    Roblox.GamesPageContainerBehavior.ExperimentalGameSortVariation = 0;
    Roblox.GamesPageContainerBehavior.DeviceTypeId = 1;

    Roblox.GamesListBehavior.RefreshAdsInGamesPageEnabled = true;
</script>

                    <div style="clear:both"></div>
                </div>
            </div>
        </div>
<div id="Footer" class="footer-container">
    <div class="FooterNav">
        <a href="/web/20141017023842/http://www.roblox.com/info/Privacy.aspx">Privacy Policy</a>
        &nbsp;|&nbsp; 
        <a href="https://web.archive.org/web/20141017023842/http://corp.roblox.com/advertise-on-roblox" class="roblox-interstitial">Advertise with Us</a>
        &nbsp;|&nbsp; 
        <a href="https://web.archive.org/web/20141017023842/http://corp.roblox.com/press" class="roblox-interstitial">Press</a>
        &nbsp;|&nbsp; 
        <a href="https://web.archive.org/web/20141017023842/http://corp.roblox.com/contact-us" class="roblox-interstitial">Contact Us</a>
        &nbsp;|&nbsp;
        <a href="https://web.archive.org/web/20141017023842/http://corp.roblox.com/about" class="roblox-interstitial">About Us</a>
        &nbsp;|&nbsp;
        <a href="https://web.archive.org/web/20141017023842/http://blog.roblox.com/" class="roblox-interstitial">Blog</a>
        &nbsp;|&nbsp;
        <a href="https://web.archive.org/web/20141017023842/http://corp.roblox.com/careers" class="roblox-interstitial">Jobs</a>
        &nbsp;|&nbsp;
        <a href="https://web.archive.org/web/20141017023842/http://corp.roblox.com/parents" class="roblox-interstitial">Parents</a>
            <span class="LanguageOptionElement">&nbsp;|&nbsp;</span>
            <span ref="footer-parents" class="LanguageOptionElement LanguageTrigger roblox-interstitial" drop-down-nav-button="LanguageTrigger">English&nbsp;<span class="FooterArrow">▼</span>
                <div class="dropuplanguagecontainer" style="display:none;" data-drop-down-nav-container="LanguageTrigger">
                    <div class="dropdownmainnav" style="z-index:1023">
                            <a href="/web/20141017023842/http://www.roblox.com/UserLanguage/LanguageRedirect?languageCode=de&amp;relativePath=%2fGames" class="LanguageOption js-lang" data-js-langcode="de"><span class="notranslate">Deutsch</span>&nbsp;(German) </a>
                    </div>
                </div>
            </span>
    </div>
    <div class="FooterNav">
        <div id="SEOGenreLinks" class="SEOGenreLinks">
                  <a href="/web/20141017023842/http://www.roblox.com/all-games">All Games</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/building-games">Building</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/horror-games">Horror</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/town-and-city-games">Town and City</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/military-games">Military</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/comedy-games">Comedy</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/medieval-games">Medieval</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/adventure-games">Adventure</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/sci-fi-games">Sci-Fi</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/naval-games">Naval</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/fps-games">FPS</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/rpg-games">RPG</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/sports-games">Sports</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/fighting-games">Fighting</a> 
                      <span>|</span>
                  <a href="/web/20141017023842/http://www.roblox.com/western-games">Western</a> 

        </div>
    </div>
    <div class="legal">
        <div class="left">
            We are <b>NOT</b> a kid friendly game. Please note that this is a ROBLOX Private Server not affiated by ROBLOX itself. We do not intend to profit off of the <a href="http://corp.roblox.com/" ref="footer-smallabout" class="roblox-interstitial">ROBLOX Corporation</a> and its assets.
        </div>
        <div class="right">
            <p class="Legalese">
    NODE16, "Online Building Toy", characters, logos, names, and all related indicia are trademarks of <a href="http://corp.roblox.com/" ref="footer-smallabout" class="roblox-interstitial">ROBLOX Corporation</a>, ©2023. Patents pending.
    NODE16 is not sponsored, authorized or endorsed by any producer of plastic building bricks nor online games, including The LEGO Group, <a href="http://corp.roblox.com/" ref="footer-smallabout" class="roblox-interstitial">ROBLOX Corporation</a>, MEGA Brands, and K'Nex, and no resemblance to the products of these companies is intended. Use of this site signifies your acceptance of the <a href="/info/terms-of-service" ref="footer-terms">Terms and Conditions</a>.
</p>
        </div>
        <div class="clear"></div>
    </div>
</div>    </div>
    
</div> 
</div> 
</div> 
</div> 


<div id="ChatContainer" style="position:fixed; bottom:0; right:0; z-index:10020;">


</div>



<div id="PlaceLauncherStatusPanel" style="display:none;width:300px">
    <div class="modalPopup blueAndWhite PlaceLauncherModal" style="min-height: 160px">
        <div id="Spinner" class="Spinner" style="margin:0 1em 1em 0; padding:20px 0;">
            <img src="http://images.rbxcdn.com/e998fb4c03e8c2e30792f2f3436e9416.gif" height="32" width="32" alt="Progress">
        </div>
        <div id="status" style="min-height:40px;text-align:center;margin:5px 20px">
            <div id="Starting" class="PlaceLauncherStatus MadStatusStarting" style="display:block">
                Starting Roblox...
            </div>
            <div id="Waiting" class="PlaceLauncherStatus MadStatusField">Connecting to Players...</div>
            <div id="StatusBackBuffer" class="PlaceLauncherStatus PlaceLauncherStatusBackBuffer MadStatusBackBuffer"></div>
        </div>
        <div style="text-align:center;margin-top:1em">
            <input type="button" class="Button CancelPlaceLauncherButton translate" value="Cancel">
        </div>
    </div>
</div>



    <div id="videoPrerollPanel" style="display:none;">
        <div id="videoPrerollTitleDiv">
            Node16 is sponsored by:
        </div>
        <img src="/static/img/ad.png" alt="join simple's fandom today!" title="join simple's fandom today!" id="videoPrerollMainDiv"></img>
        <img src="/static/img/gametemp.png" alt="kewl!" title="kewl!" id="videoPrerollCompanionAd"></img>
        <div id="videoPrerollLoadingDiv">
            Loading <span id="videoPrerollLoadingPercent">0%</span> - <span id="videoPrerollMadStatus" class="MadStatusField">Starting game...</span><span id="videoPrerollMadStatusBackBuffer" class="MadStatusBackBuffer"></span>
            <div id="videoPrerollLoadingBar">
                <div id="videoPrerollLoadingBarCompleted">
                </div>
            </div>
        </div>
        <div id="videoPrerollJoinBC">
            <span>Get more with Builders Club!</span>
            <a href="/Upgrades/BuildersClubMemberships.aspx?ref=vpr" target="_blank" id="videoPrerollJoinBCButton"></a>
        </div>
    </div>

<div id="GuestModePrompt_BoyGirl" class="Revised GuestModePromptModal" style="display:none;">
    <div class="simplemodal-close">
        <a class="ImageButton closeBtnCircle_20h" style="cursor: pointer; margin-left:455px;top:7px; position:absolute;"></a>
    </div>
    <div class="Title">
        Choose Your Character
    </div>
    <div style="min-height: 275px; background-color: white;">
        <div style="clear:both; height:25px;"></div>

        <div style="text-align: center;">
            <div class="VisitButtonsGuestCharacter VisitButtonBoyGuest" style="float:left; margin-left:45px;"></div>
            <div class="VisitButtonsGuestCharacter VisitButtonGirlGuest" style="float:right; margin-right:45px;"></div>
        </div>
        <div style="clear:both; height:25px;"></div>
        <div class="RevisedFooter">
            <div style="width:200px;margin:10px auto 0 auto;">
                <a href="#" onclick="redirectPlaceLauncherToRegister(); return false;"><div class="RevisedCharacterSelectSignup"></div></a>
                <a class="HaveAccount" href="#" onclick="redirectPlaceLauncherToLogin();return false;">I have an account</a>
            </div>
        </div>
    </div>
</div>
<style>
    #win_firefox_install_img .activation {

    }
    #win_firefox_install_img .installation {
        width:869px;
        height:331px;
    }
    #mac_firefox_install_img .activation {}
    #mac_firefox_install_img .installation {
        width:250px; 
    }
    #win_chrome_install_img .activation {}
    #win_chrome_install_img .installation {}
    #mac_chrome_install_img .activation {
        width:250px;
    }
    #mac_chrome_install_img .installation {}

    
</style>

<div id="InstallationInstructions" class="modalPopup blueAndWhite" style="display:none;overflow:hidden">
    <a id="CancelButton2" onclick="return Roblox.Client._onCancel();" class="ImageButton closeBtnCircle_35h ABCloseCircle"></a>
    <div style="padding-bottom:10px;text-align:center">
        <br><br>
    </div>
</div>


<div class="ConfirmationModal modalPopup unifiedModal smallModal" data-modal-handle="confirmation" style="display:none;">
    <a class="genericmodal-close ImageButton closeBtnCircle_20h"></a>
    <div class="Title"></div>
    <div class="GenericModalBody">
        <div class="TopBody">
            <div class="ImageContainer roblox-item-image" data-image-size="small" data-no-overlays="" data-no-click="">
                <img class="GenericModalImage" alt="generic image">
            </div>
            <div class="Message"></div>
        </div>
        <div class="ConfirmationModalButtonContainer">
            <a href="" id="roblox-confirm-btn"><span></span></a>
            <a href="" id="roblox-decline-btn"><span></span></a>
        </div>
        <div class="ConfirmationModalFooter">
        
        </div>  
    </div>  
</div>


    <img src="https://secure.adnxs.com/seg?add=550800&amp;t=2" width="1" height="1" style="display:none;">




</body></html>