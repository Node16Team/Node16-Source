<?php
//ES_0ebaa6dc71044df5b1b6891af9bc9164
$servername = "localhost";
$username = "nodexyz_dbadmin";
$password = "phpadmin123lulz";
$dbname = "nodexyz_db";
$usernameCss = "";
$reason = "";
$passCss = "";
$passreason = "";
$sexCss = "";
$sexreason = "";
$keyCss = "";
$keyreason = "";
$capreason = "";
$gleason = "";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!ctype_alnum($_POST["username"]))
    {
        $usernameCss = " is-invalid";
        $reason = "User name is incorrect. Please read the placeholder plz!";
    }
    else if (empty($_POST["username"]) or empty($_POST["password"]) or empty($_POST["sex"]) or empty($_POST["key"]))
    {
        $gleason = "Some parts are empty, please make sure that you correctly filled in the inputs plz!";
    }
    else if (empty($_POST['h-captcha-response']))
    {
        $gleason = "HCaptcha failed, please try again plz!";
    }
    else if (strlen($_POST["key"]) != 15)
    {
        $keyCss = " is-invalid";
        $keyreason = "Key is not in requested format. Please read the placeholder plz!";
    }
    else if (strlen($_POST["username"]) < 3)
    {
        $usernameCss = " is-invalid";
        $reason = "Username is too short. Please read the placeholder plz!";
    }
    else if (strlen($_POST["username"]) < 20)
    {
        $usernameCss = " is-invalid";
        $reason = "Username is too long. Please read the placeholder plz!";
    }
}


$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Signup - Node16</title>
  <!-- Bootstrap CSS link -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <!-- hCaptcha JS link -->
  <script src="https://www.hCaptcha.com/1/api.js" async defer> </script>
  <style>
    body {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
      background: url('https://media.indiedb.com/images/games/1/50/49900/scr2.jpg') center/cover no-repeat;
      backdrop-filter: blur(3px);
    }
  </style>
</head>
<body>

<div class="card text-center" style="width: 500px; height: 520px;">
  <form action="" method="POST" class="card-body">
    <h2 class="card-title">Signup</h2>
    <p class="text-center text-danger"><?php echo $gleason; ?></p>
    <input class="form-control<?php echo $usernameCss; ?>" type="text" name="username" id="username" placeholder="Enter Username Here (alphanumeric) 3 - 20" autocomplete="on">
    <div class="invalid-feedback"><?php echo $reason; ?></div>
    <br>
    <input class="form-control<?php echo $passCss; ?>" type="password" name="password" id="password" placeholder="Enter Password Here" autocomplete="on">    <div class="invalid-feedback"><?php echo $passreason; ?></div>
    <br>
    <select class="form-control<?php echo $sexCss; ?>" name="sex" id="sex">
        <option value>Sex (NOT genders, this means only your birth sex.)</option>
        <option value="1">Male</option>
        <option value="2">Female</option>
    </select>
    <div class="invalid-feedback"><?php echo $sexreason; ?></div>
    <br>
    <input class="form-control<?php echo $keyCss; ?>" type="text" name="key" id="key" placeholder="Key (node-XX-XXXXXXX)" autocomplete="on">
    <div class="invalid-feedback"><?php echo $keyreason; ?></div>
    <br>
    <div class="h-captcha" data-sitekey="08ba0757-52b3-4a86-8017-f77847b78e55"></div>
    <br>
    <button type="submit" class="btn btn-primary">Signup</button>
    <img src="https://node16.xyz/favicon.ico">
  </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>