<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Maintenance - Node16</title>
  <!-- Bootstrap CSS link -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
      background: url('https://media.indiedb.com/images/games/1/50/49900/scr2.jpg') center/cover no-repeat;
      backdrop-filter: blur(3px);
    }
  </style>
</head>
<body>

<div class="card text-center" style="width: 500px; height: 500px;">
  <img src="./static/img/serverexploded.png" class="card-img-top" alt="Server Image">
  <div class="card-body">
    <h5 class="card-title">Maintenance</h5>
    <p class="card-text">the site is under maintenance<br>stay tuned for any updates. you can still browse the site.<br><i>-simple & the dev team</i></p>
    <img src="https://node16.xyz/favicon.ico">
    <a href="https://node16.xyz/discord/">Discord</a>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>